package com.example.portofolio2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
