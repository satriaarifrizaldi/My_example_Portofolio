import 'package:flutter/material.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final primaryColor = const Color(0xFF004080);
    
    return Scaffold(
      backgroundColor: isDark ? Colors.grey[900] : Colors.grey[50],
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 150,
            flexibleSpace: FlexibleSpaceBar(
              title: const Text(
                'Get In Touch',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [primaryColor, const Color(0xFF00264D)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
            pinned: true,
            backgroundColor: primaryColor,
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    // Contact Info Cards
                    _buildContactInfoSection(primaryColor),
                    
                    const SizedBox(height: 32),
                    
                    // Send Message Section
                    _buildMessageSection(primaryColor, context),
                    
                    const SizedBox(height: 40),
                    
                    // Social Media Links
                    _buildSocialMediaSection(primaryColor),
                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _buildContactInfoSection(Color primaryColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Contact Information',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Color(0xFF001F3F),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Feel free to reach out through any of these channels',
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
        const SizedBox(height: 20),
        
        // Contact Cards
        _buildContactCard(
          icon: Icons.email_outlined,
          title: 'Email',
          subtitle: 'satria.arif@example.com',
          description: 'I\'ll respond within 24 hours',
          color: Colors.red[400]!,
          primaryColor: primaryColor,
        ),
        
        const SizedBox(height: 16),
        
        _buildContactCard(
          icon: Icons.phone_outlined,
          title: 'Phone',
          subtitle: '+62 812-3456-7890',
          description: 'Available Mon - Fri, 9AM - 6PM',
          color: Colors.green[400]!,
          primaryColor: primaryColor,
        ),
        
        const SizedBox(height: 16),
        
        _buildContactCard(
          icon: Icons.location_on_outlined,
          title: 'Location',
          subtitle: 'Indonesia',
          description: 'Open to remote opportunities',
          color: Colors.orange[400]!,
          primaryColor: primaryColor,
        ),
      ],
    );
  }

  Widget _buildContactCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required String description,
    required Color color,
    required Color primaryColor,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, Colors.grey[50]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: color.withOpacity(0.3)),
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: primaryColor,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMessageSection(Color primaryColor, BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white, const Color(0xFFF8F9FA)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: primaryColor,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.message_outlined,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Send Message',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF001F3F),
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 8),
              
              Text(
                'Have a project in mind or want to collaborate? Send me a message!',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              
              const SizedBox(height: 24),
              
              _buildCustomTextField(
                label: 'Your Name',
                icon: Icons.person_outline,
                primaryColor: primaryColor,
              ),
              
              const SizedBox(height: 16),
              
              _buildCustomTextField(
                label: 'Your Email',
                icon: Icons.email_outlined,
                primaryColor: primaryColor,
              ),
              
              const SizedBox(height: 16),
              
              _buildCustomTextField(
                label: 'Subject',
                icon: Icons.subject_outlined,
                primaryColor: primaryColor,
              ),
              
              const SizedBox(height: 16),
              
              // Message Field
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Row(
                        children: [
                          Icon(Icons.message_outlined, color: primaryColor, size: 20),
                          const SizedBox(width: 8),
                          Text(
                            'Message',
                            style: TextStyle(
                              color: Colors.grey[600],
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    TextFormField(
                      maxLines: 5,
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 24),
              
              FilledButton(
                onPressed: () {
                  _showSuccessMessage(context, primaryColor);
                },
                style: FilledButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 2,
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.send_outlined, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'Send Message',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCustomTextField({
    required String label,
    required IconData icon,
    required Color primaryColor,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Icon(icon, color: primaryColor, size: 20),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          TextFormField(
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialMediaSection(Color primaryColor) {
    final socialMedia = [
      _SocialMediaItem(
        name: 'LinkedIn',
        icon: Icons.work_outline,
        color: const Color(0xFF0077B5),
        handle: 'satria-arif-rizaldi',
      ),
      _SocialMediaItem(
        name: 'GitHub',
        icon: Icons.code_outlined,
        color: const Color(0xFF333333),
        handle: 'satriaarif',
      ),
      _SocialMediaItem(
        name: 'Twitter',
        icon: Icons.chat_outlined,
        color: const Color(0xFF1DA1F2),
        handle: '@satria_arif',
      ),
    ];

    return Column(
      children: [
        const Text(
          'Follow Me On',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF001F3F),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: socialMedia.map((social) => _buildSocialMediaCard(social, primaryColor)).toList(),
        ),
      ],
    );
  }

  Widget _buildSocialMediaCard(_SocialMediaItem social, Color primaryColor) {
    return GestureDetector(
      onTap: () {
        // Handle social media tap
      },
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: social.color.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: social.color.withOpacity(0.3)),
            ),
            child: Icon(social.icon, color: social.color, size: 28),
          ),
          const SizedBox(height: 8),
          Text(
            social.name,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: primaryColor,
            ),
          ),
        ],
      ),
    );
  }

  void _showSuccessMessage(BuildContext context, Color primaryColor) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 8),
            const Text('Message sent successfully!'),
          ],
        ),
        backgroundColor: primaryColor,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }
}

class _SocialMediaItem {
  final String name;
  final IconData icon;
  final Color color;
  final String handle;

  _SocialMediaItem({
    required this.name,
    required this.icon,
    required this.color,
    required this.handle,
  });
}