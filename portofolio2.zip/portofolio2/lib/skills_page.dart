import 'package:flutter/material.dart';

class SkillsPage extends StatelessWidget {
  const SkillsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 150,
            flexibleSpace: FlexibleSpaceBar(
              title: const Text(
                'Skills & Technologies',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF004080), Color(0xFF00264D)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
            pinned: true,
            backgroundColor: const Color(0xFF004080),
          ),
          SliverList(
            delegate: SliverChildListDelegate(
              [
                const SizedBox(height: 24),
                _buildSkillCategory(
                  title: 'Programming Languages',
                  skills: [
                    const _SkillItem(
                      name: 'Python',
                      level: 95,
                      icon: Icons.code,
                      color: Colors.blue,
                    ),
                    const _SkillItem(
                      name: 'R',
                      level: 85,
                      icon: Icons.bar_chart,
                      color: Colors.blue,
                    ),
                    const _SkillItem(
                      name: 'SQL',
                      level: 90,
                      icon: Icons.storage,
                      color: Colors.green,
                    ),
                    const _SkillItem(
                      name: 'JavaScript',
                      level: 75,
                      icon: Icons.web,
                      color: Colors.amber,
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                _buildSkillCategory(
                  title: 'Machine Learning & AI',
                  skills: [
                    const _SkillItem(
                      name: 'TensorFlow',
                      level: 90,
                      icon: Icons.smart_toy,
                      color: Colors.orange,
                    ),
                    const _SkillItem(
                      name: 'PyTorch',
                      level: 85,
                      icon: Icons.psychology,
                      color: Colors.red,
                    ),
                    const _SkillItem(
                      name: 'Scikit-learn',
                      level: 95,
                      icon: Icons.auto_graph,
                      color: Colors.blue,
                    ),
                    const _SkillItem(
                      name: 'Keras',
                      level: 80,
                      icon: Icons.layers,
                      color: Colors.red,
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                _buildSkillCategory(
                  title: 'Data Analysis & Visualization',
                  skills: [
                    const _SkillItem(
                      name: 'Pandas',
                      level: 95,
                      icon: Icons.table_chart,
                      color: Colors.purple,
                    ),
                    const _SkillItem(
                      name: 'NumPy',
                      level: 90,
                      icon: Icons.functions,
                      color: Colors.blue,
                    ),
                    const _SkillItem(
                      name: 'Matplotlib',
                      level: 85,
                      icon: Icons.show_chart,
                      color: Colors.green,
                    ),
                    const _SkillItem(
                      name: 'Seaborn',
                      level: 80,
                      icon: Icons.analytics,
                      color: Colors.pink,
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                _buildSkillCategory(
                  title: 'Tools & Technologies',
                  skills: [
                    const _SkillItem(
                      name: 'Git',
                      level: 90,
                      icon: Icons.account_tree,
                      color: Colors.orange,
                    ),
                    const _SkillItem(
                      name: 'Docker',
                      level: 75,
                      icon: Icons.settings,
                      color: Colors.blue,
                    ),
                    const _SkillItem(
                      name: 'AWS',
                      level: 70,
                      icon: Icons.cloud,
                      color: Colors.amber,
                    ),
                    const _SkillItem(
                      name: 'MongoDB',
                      level: 80,
                      icon: Icons.storage, // Ganti dari Icons.database
                      color: Colors.green,
                    ),
                  ],
                ),
                const SizedBox(height: 40),
                _buildTechStackSection(),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSkillCategory({
    required String title,
    required List<Widget> skills,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            blurRadius: 10,
            color: Colors.black.withOpacity(0.1),
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              children: [
                Container(
                  width: 4,
                  height: 24,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF001F3F),
                  ),
                ),
              ],
            ),
          ),
          ...skills,
        ],
      ),
    );
  }

  Widget _buildTechStackSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            blurRadius: 10,
            color: Colors.black.withOpacity(0.1),
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Tech Stack',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xFF001F3F),
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: const [
              _TechStackItem(tech: 'Python', color: Colors.blue),
              _TechStackItem(tech: 'TensorFlow', color: Colors.orange),
              _TechStackItem(tech: 'PyTorch', color: Colors.red),
              _TechStackItem(tech: 'Pandas', color: Colors.purple),
              _TechStackItem(tech: 'SQL', color: Colors.green),
              _TechStackItem(tech: 'Docker', color: Colors.blue),
              _TechStackItem(tech: 'AWS', color: Colors.amber),
              _TechStackItem(tech: 'Git', color: Colors.orange),
            ],
          ),
        ],
      ),
    );
  }
}

class _SkillItem extends StatelessWidget {
  final String name;
  final int level;
  final IconData icon;
  final Color color;

  const _SkillItem({
    required this.name,
    required this.level,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Color.alphaBlend(color.withOpacity(0.1), Colors.white),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF001F3F),
                      ),
                    ),
                    Text(
                      '$level%',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.blue,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: level / 100,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [color, _lightenColor(color, 0.3)],
                        ),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _lightenColor(Color color, double factor) {
    return Color.alphaBlend(
      Colors.white.withOpacity(factor),
      color,
    );
  }
}

class _TechStackItem extends StatelessWidget {
  final String tech;
  final Color color;

  const _TechStackItem({
    required this.tech,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Color.alphaBlend(color.withOpacity(0.1), Colors.white),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Color.alphaBlend(color.withOpacity(0.3), Colors.white),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            tech,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}