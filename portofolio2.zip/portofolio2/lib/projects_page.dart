import 'package:flutter/material.dart';

class ProjectsPage extends StatelessWidget {
  const ProjectsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: CustomScrollView(
        slivers: [
          const SliverAppBar(
            expandedHeight: 150,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'My Projects',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              background: _GradientBackground(),
            ),
            pinned: true,
            backgroundColor: Color(0xFF004080),
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              const SizedBox(height: 24),
              const _ProjectGrid(),
              const SizedBox(height: 40),
            ]),
          ),
        ],
      ),
    );
  }
}

class _GradientBackground extends StatelessWidget {
  const _GradientBackground();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF004080), Color(0xFF00264D)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
    );
  }
}

class _ProjectGrid extends StatelessWidget {
  const _ProjectGrid();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          ProjectCard(
            projectName: 'Predictive Maintenance System',
            description: 'Machine learning system that predicts equipment failures using IoT sensor data and time-series analysis. Reduces maintenance costs by 40% and prevents unexpected downtime.',
            technologies: ['Python', 'TensorFlow', 'LSTM', 'IoT', 'AWS'],
            teamMembers: ['Satria Arif Rizaldi (Lead)', 'Data Engineer (1)', 'ML Engineer (1)'],
            status: 'Completed',
            duration: '6 months',
            imagePaths: [
              'assets/images/predictive_maintenance_1.jpg',
              'assets/images/predictive_maintenance_2.jpg',
              'assets/images/predictive_maintenance_3.jpg',
            ],
            results: [
              '95% prediction accuracy',
              '40% cost reduction',
              'Zero unexpected downtime'
            ],
            category: 'Machine Learning',
          ),
          SizedBox(height: 24),
          ProjectCard(
            projectName: 'Customer Churn Prediction',
            description: 'Classification model that identifies customers likely to churn with 92% accuracy using ensemble methods and feature engineering. Integrated with company CRM system.',
            technologies: ['Scikit-learn', 'XGBoost', 'Pandas', 'Matplotlib', 'Flask'],
            teamMembers: ['Satria Arif Rizaldi (Solo)'],
            status: 'Deployed',
            duration: '3 months',
            imagePaths: [
              'assets/images/churn_prediction_1.jpg',
              'assets/images/churn_prediction_2.jpg',
              'assets/images/churn_prediction_3.jpg',
            ],
            results: [
              '92% prediction accuracy',
              '15% churn reduction',
              'Real-time API deployment'
            ],
            category: 'Data Science',
          ),
          SizedBox(height: 24),
          ProjectCard(
            projectName: 'Medical Image Analysis AI',
            description: 'Deep learning model for detecting anomalies in medical images using convolutional neural networks. Assists radiologists in early disease detection.',
            technologies: ['PyTorch', 'CNN', 'OpenCV', 'Docker', 'FastAPI'],
            teamMembers: ['Satria Arif Rizaldi (ML Lead)', 'Medical Expert (2)', 'Backend Developer (1)'],
            status: 'In Progress',
            duration: '8 months',
            imagePaths: [
              'assets/images/medical_ai_1.jpg',
              'assets/images/medical_ai_2.jpg',
              'assets/images/medical_ai_3.jpg',
            ],
            results: [
              '98% detection accuracy',
              '30% faster diagnosis',
              'FDA approval pending'
            ],
            category: 'Deep Learning',
          ),
        ],
      ),
    );
  }
}

class ProjectCard extends StatelessWidget {
  final String projectName;
  final String description;
  final List<String> technologies;
  final List<String> teamMembers;
  final String status;
  final String duration;
  final List<String> imagePaths;
  final List<String> results;
  final String category;

  const ProjectCard({
    super.key,
    required this.projectName,
    required this.description,
    required this.technologies,
    required this.teamMembers,
    required this.status,
    required this.duration,
    required this.imagePaths,
    required this.results,
    required this.category,
  });

  // Helper method untuk blend color tanpa withOpacity
  Color _blendColor(Color color, int opacityValue) {
    final opacity = opacityValue / 100;
    final red = (color.red * opacity + 255 * (1 - opacity)).round();
    final green = (color.green * opacity + 255 * (1 - opacity)).round();
    final blue = (color.blue * opacity + 255 * (1 - opacity)).round();
    return Color.fromARGB(255, red, green, blue);
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _getStatusColor(status);
    final categoryColor = _getCategoryColor(category);
    
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Project Header dengan Status dan Category
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        projectName,
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF001F3F),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _blendColor(categoryColor, 10),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          category,
                          style: TextStyle(
                            color: categoryColor,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _blendColor(statusColor, 10),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: statusColor),
                  ),
                  child: Text(
                    status,
                    style: TextStyle(
                      color: statusColor,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            // Project Duration
            Row(
              children: [
                const Icon(Icons.schedule, size: 16, color: Colors.grey),
                const SizedBox(width: 6),
                Text(
                  'Duration: $duration',
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Project Description
            Text(
              description,
              style: const TextStyle(
                fontSize: 16,
                color: Colors.grey,
                height: 1.5,
              ),
            ),
            
            const SizedBox(height: 20),
            
            // Image Grid dengan Gambar Asli
            _buildImageGrid(context),
            
            const SizedBox(height: 20),
            
            // Team Section
            const Text(
              'Team Members',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Color(0xFF001F3F),
              ),
            ),
            const SizedBox(height: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: teamMembers.map((member) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      decoration: const BoxDecoration(
                        color: Color(0xFFE3F2FD),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.person,
                        size: 14,
                        color: Color(0xFF1976D2),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      member,
                      style: const TextStyle(
                        color: Colors.grey,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              )).toList(),
            ),
            
            const SizedBox(height: 20),
            
            // Technologies Used
            const Text(
              'Technologies Used',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Color(0xFF001F3F),
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: technologies.map((tech) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: const BoxDecoration(
                  color: Color(0xFFE3F2FD),
                  borderRadius: BorderRadius.all(Radius.circular(16)),
                  border: Border.fromBorderSide(BorderSide(color: Color(0xFFBBDEFB))),
                ),
                child: Text(
                  tech,
                  style: const TextStyle(
                    color: Color(0xFF0D47A1),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              )).toList(),
            ),
            
            const SizedBox(height: 20),
            
            // Results/Achievements
            const Text(
              'Key Results',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Color(0xFF001F3F),
              ),
            ),
            const SizedBox(height: 8),
            Column(
              children: results.map((result) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 20,
                      height: 20,
                      decoration: const BoxDecoration(
                        color: Color(0xFFE8F5E8),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.check,
                        size: 14,
                        color: Color(0xFF4CAF50),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        result,
                        style: const TextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
              )).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageGrid(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;
    final crossAxisCount = isMobile ? 2 : 3;
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Project Gallery',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Color(0xFF001F3F),
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: isMobile ? 0.8 : 1.0,
          ),
          itemCount: imagePaths.length,
          itemBuilder: (context, index) {
            return _buildImageItem(imagePaths[index], index, isMobile);
          },
        ),
      ],
    );
  }

  Widget _buildImageItem(String imagePath, int index, bool isMobile) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x1A000000),
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          children: [
            // Gambar utama
            Image.asset(
              imagePath,
              width: double.infinity,
              height: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                print('Error loading image: $imagePath - $error');
                return _buildImagePlaceholder(index, isMobile);
              },
            ),
            
            // Gradient overlay untuk text readability
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    Colors.black.withOpacity(0.6),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            
            // Image label
            Positioned(
              bottom: 8,
              left: 8,
              right: 8,
              child: Text(
                'Preview ${index + 1}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImagePlaceholder(int index, bool isMobile) {
    final placeholderData = _getPlaceholderData(index);
    
    return Container(
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        gradient: placeholderData.gradient,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            placeholderData.icon,
            size: isMobile ? 24 : 32,
            color: Colors.white,
          ),
          const SizedBox(height: 8),
          Text(
            placeholderData.title,
            style: TextStyle(
              color: Colors.white,
              fontSize: isMobile ? 10 : 12,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  _PlaceholderData _getPlaceholderData(int index) {
    const placeholders = [
      _PlaceholderData(
        icon: Icons.analytics,
        title: 'Data Visualization',
        gradient: LinearGradient(
          colors: [Color(0xFF667eea), Color(0xFF764ba2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      _PlaceholderData(
        icon: Icons.model_training,
        title: 'ML Model',
        gradient: LinearGradient(
          colors: [Color(0xFFf093fb), Color(0xFFf5576c)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      _PlaceholderData(
        icon: Icons.psychology,
        title: 'AI Analysis',
        gradient: LinearGradient(
          colors: [Color(0xFF4facfe), Color(0xFF00f2fe)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
    ];
    
    return placeholders[index % placeholders.length];
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return const Color(0xFF4CAF50);
      case 'deployed':
        return const Color(0xFF2196F3);
      case 'in progress':
        return const Color(0xFFFF9800);
      default:
        return const Color(0xFF9E9E9E);
    }
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'machine learning':
        return const Color(0xFF9C27B0);
      case 'data science':
        return const Color(0xFF2196F3);
      case 'deep learning':
        return const Color(0xFFF44336);
      case 'data visualization':
        return const Color(0xFF4CAF50);
      default:
        return const Color(0xFF9E9E9E);
    }
  }
}

class _PlaceholderData {
  final IconData icon;
  final String title;
  final LinearGradient gradient;

  const _PlaceholderData({
    required this.icon,
    required this.title,
    required this.gradient,
  });
}